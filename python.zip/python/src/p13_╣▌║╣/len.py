names = ["김준일", "강주현", "이영현", "서현준", "박노진", "송지한", "김예진", "서재효"]

for i in range(len(names)):
    print(f"이름: {names[i]}")