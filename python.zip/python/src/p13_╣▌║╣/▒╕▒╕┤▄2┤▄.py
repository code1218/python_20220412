dan = 2
num = 0
result = 0

while num < 9:
    num += 1
    result = dan * num
    print(f"{dan} X {num} = {result}")