list1 = [1,2,3,4,5]

for i in list1:
    print(i)


list2 = [(1,2), (5,6), (10,11)]

for (i, j) in list2:
    print(f"i = {i}, j = {j}")