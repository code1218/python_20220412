from copy import copy

a = [1,2,3,4,5,6]
b = copy(a)
c = a[:]

print(b)
print(c)