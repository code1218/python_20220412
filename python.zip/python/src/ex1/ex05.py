str1 = "a:b:c:d"
result1 = str1.replace(":", "#")

print(f"변환된 결과: {result1}")



# 변환된 결과: a#b#c#d