kor = 80
eng = 75
math = 55

# 홍길동씨의 평균은 00입니다.
print("홍길동씨의 평균은 {0}입니다.".format((kor + eng + math) / 3))
print(f"홍길동씨의 평균은 {(kor + eng + math) / 3}입니다.")
print("홍길동씨의 평균은 %.1f입니다." % ((kor + eng + math) / 3))
