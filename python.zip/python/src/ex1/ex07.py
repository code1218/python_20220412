a = ['Life', 'is', 'too', 'short']
b = " ".join(a)
print(b)