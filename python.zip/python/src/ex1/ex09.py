a = dict()
print(type(a))

#a[[1, 2]] = 'python'
a[(1,)] = 'python'

print(a.get((1,)))

