n = int(input("별의 개수: "))
i = 0

while i < n:
    i += 1
    print("*" * i) 

n = int(input("별의 개수: "))
i = 0

while i < n:
    print("*" * (n - i)) 
    i += 1

