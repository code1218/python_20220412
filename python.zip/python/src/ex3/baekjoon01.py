n = int(input("반복 횟수를 입력하세요: "))
i = 0

while i < n:
    i += 1
    print(i)

print()

n = int(input("반복 횟수를 입력하세요: "))
i = 0

while i < n:
    print(n-i)
    i += 1
