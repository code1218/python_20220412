set1 = {1,2,3,4,5}
set2 = {1,3,5,7,9}

set3 = set1.intersection(set2)
print(set3)

set4 = set1.union(set2)
print(set4)

set5 = set1.difference(set2)
print(set5)