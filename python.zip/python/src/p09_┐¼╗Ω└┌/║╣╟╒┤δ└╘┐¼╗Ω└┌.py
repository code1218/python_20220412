a = 10
b = 20

a = a + b
a += b
a -= b
a *= b
a **= b
a /= b
a //= b
a %= b
