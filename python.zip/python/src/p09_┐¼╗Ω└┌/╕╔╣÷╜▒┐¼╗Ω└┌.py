list1 = ['a', 'b', 'c']
result1 = 'a' in list1
result2 = 'd' not in list1


print(f"맴버쉽연산 결과: {result1}")
print(f"맴버쉽연산 결과: {result2}")