a = True
b = False

result = a and b
reuslt = a or b
result = not(a or b)