num1, num2 = map(int, input("두수를 입력해주세요: ").split())

print(f"첫번째 수: {type(num1)}, 두번째 수: {type(num2)}")