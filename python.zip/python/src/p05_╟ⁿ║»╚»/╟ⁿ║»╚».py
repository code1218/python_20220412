a = 10
b = "20"
c = 3.14

print(a)
print(b)
print(a + int(b))
print(str(a) + b)
print(a + c)
