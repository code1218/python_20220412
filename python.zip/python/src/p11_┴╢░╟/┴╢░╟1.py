money = True

if money:
    print('택시를 타고 가라')
    print('택시비를 내고 내려라')
else:
    print('돈없으면 걸어다녀라')

    print('무조건 실행')