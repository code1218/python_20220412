point = 900
result = ("골드" if point > 799 else "실버") if point > 699 else ("브론즈" if point > 499 else "일반회원")

print(result)