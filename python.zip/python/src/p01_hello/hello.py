print("hello, python!")
print("이름: 김준일")
print("연락처: 010-9988-1916")
print("이메일: skjil1218@kakao.com")
print("주소: 부산 동래구")
print(10)
print(10.5)
print(0o77)
print(0xff)

a = 10;

a = 3
a = 3 + 1
print(a)

b = 4 / 3
print(b)

b = 4 // 3
print(b)

b = 5 % 3
print(b)

b = 3 ** 4
print(b)


b = 4 / 3
print(b)
print(type(b))

b = "\"안녕하세요.\""
print(b)

b = "안녕하세요.\n반갑습니다."

c = """안녕하세요
반갑습니다."""

print(b)
print(c)

print("파이썬" + " 문자열 합치기")
py = "파이썬"
str = "문자열 합치기"

print(py, str)

l = len(py)
print(l)

py = py * 3
print(py[-2])

a = "20220315 python study"
date = a[:8]
study = a[-1:-5:-1]

print(date)
print(study)